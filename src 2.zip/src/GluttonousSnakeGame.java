import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Random;

public class GluttonousSnakeGame extends JPanel implements ActionListener, KeyListener {
	// Game panel dimensions and unit size
    private static final int WIDTH = 400, HEIGHT = 400, UNIT_SIZE = 20;
    // Total number of possible game units (positions)
    private static final int GAME_UNITS = (WIDTH * HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    // Timer delay in milliseconds (game speed)
    private static final int DELAY = 150;
    
    // Snake body represented as a list of points
    private final LinkedList<Point> snake = new LinkedList<>();
    private Point food; // Current food position
    private char direction = 'R'; // U, D, L, R
    private boolean running = false; 
    private Timer timer;  
    private Random random; // Random generator for placing food.

    public GluttonousSnakeGame() {
        random = new Random();
        setPreferredSize(new Dimension(WIDTH, HEIGHT)); //set panel size
        setBackground(Color.black); 
        setFocusable(true); //allow panel to receive focus for key point
        addKeyListener(this);
        startGame();
    }

    public void startGame() {
        snake.clear(); // clear any existing snake data
        // Add initial snake head and body segment
        snake.add(new Point(UNIT_SIZE * 5, UNIT_SIZE * 5));
        snake.add(new Point(UNIT_SIZE * 4, UNIT_SIZE * 5));
        placeFood();
        running = true; // set game to running
        timer = new Timer(DELAY, this); // create timer with delay and action listener
        timer.start();
    }

    private void placeFood() {
    	// Randomly generate x and y within grid, then create food point
        int x = random.nextInt((int)(WIDTH / UNIT_SIZE)) * UNIT_SIZE;
        int y = random.nextInt((int)(HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
        food = new Point(x, y);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // clear the panel
        draw(g); // draw game elements
    }

    private void draw(Graphics g) {
        if (running) {
            // draw food
            g.setColor(Color.red);
            g.fillOval(food.x, food.y, UNIT_SIZE, UNIT_SIZE);

            // draw snake
            for (int i = 0; i < snake.size(); i++) {
                if (i == 0) g.setColor(Color.green);
                else g.setColor(new Color(45, 180, 0));
                Point p = snake.get(i); // get current segment
                g.fillRect(p.x, p.y, UNIT_SIZE, UNIT_SIZE); // draw segment
            }

            // score
            g.setColor(Color.white);
            g.setFont(new Font("Ink Free", Font.BOLD, 20));
            String scoreText = "Score: " + (snake.size() - 2);
            FontMetrics metrics = getFontMetrics(g.getFont());
            // center the score string
            g.drawString(scoreText, (WIDTH - metrics.stringWidth(scoreText)) / 2, g.getFont().getSize());
        } else {
            gameOver(g); // if the game not running, show game over screen
        }
    }

    private void move() {
        Point head = new Point(snake.getFirst());
        // Update head position based on direction
        switch (direction) {
            case 'U': head.y -= UNIT_SIZE; break;
            case 'D': head.y += UNIT_SIZE; break;
            case 'L': head.x -= UNIT_SIZE; break;
            case 'R': head.x += UNIT_SIZE; break;
        }
        snake.addFirst(head); // add new head to snake
        if (head.equals(food)) {
            placeFood(); // if food eaten, place new food (snake grows)
        } else {
            snake.removeLast(); // else move forward by removing tail
        }
    }

    private void checkCollisions() {
        Point head = snake.getFirst();
        // Check collision with walls
        if (head.x < 0 || head.x >= WIDTH || head.y < 0 || head.y >= HEIGHT) running = false;
        // check collision with self
        for (int i = 1; i < snake.size(); i++) {
            if (head.equals(snake.get(i))) running = false;
        }
        if (!running) timer.stop(); // stop the timer if game over
    }

    private void gameOver(Graphics g) {
        // Display Game Over text
        g.setColor(Color.white);
        g.setFont(new Font("Ink Free", Font.BOLD, 40));
        String msg = "Game Over";
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString(msg, (WIDTH - metrics.stringWidth(msg)) / 2, HEIGHT / 2 - 20);

        // Display final score
        g.setFont(new Font("Ink Free", Font.BOLD, 20));
        String score = "Score: " + (snake.size() - 2);
        metrics = getFontMetrics(g.getFont());
        g.drawString(score, (WIDTH - metrics.stringWidth(score)) / 2, HEIGHT / 2 + 20);

        // Display restart/exit prompt
        g.setFont(new Font("Ink Free", Font.PLAIN, 16));
        String prompt = "Press SPACE to Restart or ESC to Exit";
        metrics = getFontMetrics(g.getFont());
        g.drawString(prompt, (WIDTH - metrics.stringWidth(prompt)) / 2, HEIGHT / 2 + 60);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move(); // move snake each timer tick
            checkCollisions(); // then check for collisions
        }
        repaint(); // repaint panel to update visuals
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
        	// change direction left if not moving right
            case KeyEvent.VK_LEFT: if (direction != 'R') direction = 'L'; break;
            // change direction right if not moving left
            case KeyEvent.VK_RIGHT: if (direction != 'L') direction = 'R'; break;
            // change direction up if not moving down
            case KeyEvent.VK_UP: if (direction != 'D') direction = 'U'; break;
            // change direction down if not moving up
            case KeyEvent.VK_DOWN: if (direction != 'U') direction = 'D'; break;
            case KeyEvent.VK_SPACE:
                if (!running) startGame(); // restart game on space
                break;
            case KeyEvent.VK_ESCAPE:
                SwingUtilities.getWindowAncestor(this).dispose(); // exit game window on escape
                break;
        }
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
    }
