import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainGameUI extends JFrame {
    private Tamagotchi pet;   //pet model
    private Player player;    //handles action
    private Logic logic;      //game logic controller

    // UI Components
    private JProgressBar healthBar;      //print out the health bar
    private JProgressBar happinessBar;   //print out the happiness bar
    private JProgressBar hungerBar;      //print out the hunger bar
    private JLabel statusLabel;          //Label showing current status
    private JLabel characterLabel;       //Label for displaying character
    private JButton dateButton;          //Button to trigger date action

    public MainGameUI() {
        // Prompt for pronouns at startup
        String pronouns = promptPronouns();   //ask for pronouns
        this.pet = new Tamagotchi("Default", pronouns);   // Create pet with default name
        this.player = new Player("Player");   //Initialize player
        this.logic = new Logic(pet, player);  // Initialize logic

        pet.startDayCycle();  //begin day
        initializeUI();       //build UI
        updateAll();        //refresh display
    }

    public MainGameUI(String petName, String pronouns, String character) {
        this.pet = new Tamagotchi(petName, pronouns);  // Create pet with custom name and pronouns
        this.player = new Player("Player");  // Initialize player
        this.logic = new Logic(pet, player); // Initialize logic

        initializeUI();
        updateCharacterDisplay(character);  // Show chosen character label
        updateAll();
        setTitle("Little Life - " + petName);  // Set window title to include pet name
    }

     
    private String promptPronouns() {  // Dialog to choose pronouns
        String[] options = {"he/him", "she/her", "they/them"};
        String choice = (String) JOptionPane.showInputDialog(
            null,
            "Choose your pet's pronouns:",  // Prompt message
            "Pronouns Selection",           // Dialog title
            JOptionPane.QUESTION_MESSAGE,   // Dialog type
            null, 
            options,                        // Selection options
            options[2]                      // Default selection (they/them)
        );
        return (choice != null && !choice.isEmpty()) ? choice : "they/them";    // Fallback if cancelled
    }

    private void initializeUI() {  //setup frame and layout
        setTitle("Little Life - Main Game");    //window title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // Exit on close
        setSize(600, 500);       // Window dimensions
        setLocationRelativeTo(null);     // Center window
        setResizable(false);
        getContentPane().setBackground(new Color(252, 252, 206));  // Panel background color
        setLayout(new BorderLayout(10, 10));   // Use BorderLayout with gaps

        add(createTopPanel(), BorderLayout.NORTH);   // Top status panel
        add(createCenterPanel(), BorderLayout.CENTER);   // Center character + status
        add(createBottomPanel(), BorderLayout.SOUTH);    // Bottom actions panel
        setVisible(true);                                //show window
    }

    private JPanel createTopPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));  // Centered flow layout
        panel.setBackground(new Color(252, 252, 206));   // Match background

        statusLabel = new JLabel(pet.getName() + " Status: Happy");   // Initial status text
        statusLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 16));   // Bold font
        statusLabel.setForeground(new Color(0x8B4513));   // Text color
        panel.add(statusLabel);                 // Add to panel

        JLabel favFood = new JLabel("Favorite Food: " + pet.getFavoriteFood());   // Show favorite food
        favFood.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));   // Plain font
        favFood.setForeground(new Color(0x8B4513));   // Text color
        panel.add(favFood);        // Add to panel

        return panel;
    }

    private JPanel createCenterPanel() {    
        JPanel panel = new JPanel(new BorderLayout());    // BorderLayout container
        panel.setBackground(new Color(252, 252, 206));    // Match background

        characterLabel = new JLabel(pet.getName(), JLabel.CENTER);   // Centered text
        characterLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 18));  // Bold font
        characterLabel.setPreferredSize(new Dimension(200, 200));   // Reserve space
        characterLabel.setIcon(createPlaceholderIcon(150, 150));   // Draw placeholder character
        characterLabel.setHorizontalTextPosition(SwingConstants.CENTER); // Let name of the character be on the top
        characterLabel.setVerticalTextPosition(SwingConstants.TOP);
        characterLabel.setIconTextGap(30);    // bump the text further away from the icon
        panel.add(characterLabel, BorderLayout.CENTER);   // Add character center
        panel.add(createStatsPanel(), BorderLayout.EAST);    // Add status bar to the right
        return panel;
    }

    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));   // 3 rows, 1 column
        panel.setBackground(new Color(252, 252, 206));      // Match background
        panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 20));   // Padding

        healthBar = new JProgressBar(0, 100);   // Range 0-100
        happinessBar = new JProgressBar(0, 100);
        hungerBar = new JProgressBar(0, 100);

        panel.add(makeBarPanel("Health", healthBar));  // Add bar row
        panel.add(makeBarPanel("Happiness", happinessBar));
        panel.add(makeBarPanel("Hunger", hungerBar));

        return panel;     // Return status panel
    }

    private JPanel makeBarPanel(String label, JProgressBar bar) {
        JPanel p = new JPanel(new BorderLayout(5, 0));   // BorderLayout for label+bar
        p.setBackground(new Color(252, 252, 206));
        JLabel l = new JLabel(label + ": ");    // Label text
        l.setFont(new Font("Comic Sans MS", Font.BOLD, 14));  // Bold font
        p.add(l, BorderLayout.WEST);    // Add label left
        bar.setStringPainted(true);     // Show numeric value
        p.add(bar, BorderLayout.CENTER);  // Add bar center
        return p;
    }

    private JPanel createBottomPanel() {            // Builds action button panel
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10)); // Centered with gaps
        panel.setBackground(new Color(252, 252, 206)); // Match background
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0)); // Top/bottom padding

        JButton feedBtn = createActionButton("Feed", "🍎"); // Feed button
        feedBtn.addActionListener(e -> showFeedOptions()); // Show feed dialog
        JButton playBtn = createActionButton("Play", "🎮"); // Play button
        playBtn.addActionListener(e -> showPlayOptions()); // Show play dialog
        
        dateButton = createActionButton("Date", "❤"); // Date button
        dateButton.setEnabled(true);  // always clickable
        dateButton.addActionListener(e -> showDateOptions()); // Show date dialog
        JButton nextBtn = createActionButton("Next Day", "🌙"); // Next day button
        nextBtn.addActionListener(e -> handleNextDay()); // Advance day

        panel.add(feedBtn);                       // Add Feed
        panel.add(playBtn);                       // Add Play
        panel.add(dateButton);                    // Add Date
        panel.add(nextBtn);                       // Add Next Day
        return panel;                             // Return bottom panel
    }

    private void showFeedOptions() {
        if (pet.isSick()) {
            int choice = JOptionPane.showConfirmDialog(
                this,
                pet.getName() + " is sick! Give medicine?",
                "Pet is Sick", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (choice == JOptionPane.YES_OPTION) {
                pet.changeHealth(10);
                pet.changeHappiness(-5);
                JOptionPane.showMessageDialog(this, "Medicine given: Health +10, Happiness -5");
            } else {
                pet.changeHealth(-15);
                JOptionPane.showMessageDialog(this, "No medicine: Health -15");
            }
            updateAll();
            return;
        }

        String[] options = {"Apple 🍎", "Vegetables 🥦", "Water 💧", "Soda 🥤", "Candy 🍬", "Junk Food 🍔"};
        String selection = (String) JOptionPane.showInputDialog(
            this,
            "What would you like to feed your pet?",
            "Feeding Time", JOptionPane.QUESTION_MESSAGE,
            null, options, options[0]);

        if (selection == null) return;

        if (pet.getPersonality().equals("playful") && pet.getDaysIgnored() >= 3) {
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " is angry and ignores you! 😠",
                "Ignored!", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (pet.getPersonality().equals("lazy")) {
            List<String> lazy = Arrays.asList("Fetch 🎾", "Walk 🚶");
            if (lazy.contains(selection)) {
                String act = selection.split(" ")[0].toLowerCase();
                JOptionPane.showMessageDialog(
                    this,
                    pet.getName() + " is too lazy to " + act + " right now!",
                    "Too Lazy", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        String selLower = selection.toLowerCase();
        String foodName = selLower.startsWith("junk food")  //normalize "Junk Food" to "junk food", else take first word
            ? "junk food"
            : selLower.split(" ")[0];
        
        if (foodName.equals(pet.getFavoriteFood())) {
            pet.changeEnergy(10);
            JOptionPane.showMessageDialog(
                this,
                "🎉 It's " + pet.getName() + "'s favorite food! Energy +10!",
                "Favorite Food", JOptionPane.INFORMATION_MESSAGE);
        }

        logic.makeChoice("feed", foodName);
        showFeedbackMessage("You fed your pet " + selection);
        updateStats(); checkDateEligibility(); checkPetStatus();
    }

    private void showPlayOptions() {
        if (pet.getHappiness() > 100) {
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " doesn't want to play anymore!",
                "Too Happy", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (pet.isSick()) {
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " is sick and refuses to play! Please give medicine first.",
                "Cannot Play", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] options = {"Fetch 🎾", "Walk 🚶", "Watch Movie 🎬", "Play Video Game 🎮"};
        String selection = (String) JOptionPane.showInputDialog(
            this,
            "What would you like to do with your pet?",
            "Play Time", JOptionPane.QUESTION_MESSAGE,
            null, options, options[0]);

        if (selection == null) return;

        if (pet.getPersonality().equals("lazy")) {
            List<String> lazy = Arrays.asList("Fetch 🎾", "Walk 🚶");
            if (lazy.contains(selection)) {
                String act = selection.split(" ")[0].toLowerCase();
                JOptionPane.showMessageDialog(
                    this,
                    pet.getName() + " is too lazy to " + act + " right now!",
                    "Too Lazy", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        if (selection.equals("Play Video Game 🎮")) {
        	pet.changeHunger(-5);    //video game effects
            pet.changeHappiness(10);
            updateStats(); checkDateEligibility(); checkPetStatus();  //update the status bar after playing the mini games
            JFrame snakeFrame = new JFrame("Gluttonous Snake");  
            GluttonousSnakeGame snakePanel = new GluttonousSnakeGame();   //open snake mini game in new window
            snakeFrame.add(snakePanel);
            snakeFrame.pack();
            snakeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            snakeFrame.setLocationRelativeTo(this);
            snakeFrame.setVisible(true);
            return;
        }

        if (pet.getPersonality().equals("playful") && pet.getDaysIgnored() >= 3) {
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " is angry and ignores you! 😠",
                "Ignored!", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String activity;
        if (selection.startsWith("Watch") || selection.startsWith("Play Video")) {
            String[] parts = selection.split(" ");
            activity = parts[0].toLowerCase() + " " + parts[1].toLowerCase();
        } else {
            activity = selection.split(" ")[0].toLowerCase();
        }
        logic.makeChoice("play", activity);
        if (Math.random() < 0.2) {
            String gift = getGiftByPersonality(pet.getPersonality());
            showFeedbackMessage("🎁 Surprise! " + pet.getName() + " found a " + gift + "!");
            pet.changeHappiness(10);
        }
        showFeedbackMessage("You played " + selection + " with your pet");
        updateStats(); checkDateEligibility(); checkPetStatus();
    }

    private void handleNextDay() {
        String endSummary = "🌙 End of day summary for " + pet.getName() + ":\n"
            + pet.getStatus() + "\n";
        if (pet.getHappiness() >= 70 && pet.getHealth() >= 70 && pet.getHunger() >= 70) {
            endSummary += pet.getName() + " sleeps peacefully 😴";
        } else {
            endSummary += pet.getName() + " is restless... Health may decline overnight.";
            pet.changeHealth(-5);
        }
        JOptionPane.showMessageDialog(
            this,
            endSummary,
            "End of Day Summary",
            JOptionPane.INFORMATION_MESSAGE
        );

        pet.startDayCycle();
        JOptionPane.showMessageDialog(
            this,
            "🌅 A new day begins for " + pet.getName() + "!\n" + pet.getStatus(),
            "New Day",
            JOptionPane.INFORMATION_MESSAGE
        );

        updateStats(); checkDateEligibility(); checkPetStatus();
    }

    private JButton createActionButton(String text, String emoji) {
        JButton b = new JButton(emoji + " " + text);
        b.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        b.setForeground(new Color(0x8B4513));
        b.setBackground(new Color(0xFFDAB9));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(120, 50));
        b.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2, true));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(new Color(0xFFB6C1)); b.setBorder(BorderFactory.createLineBorder(Color.WHITE,3,true)); }
            public void mouseExited(MouseEvent e) { b.setBackground(new Color(0xFFDAB9)); b.setBorder(BorderFactory.createLineBorder(Color.WHITE,2,true)); }
            public void mousePressed(MouseEvent e) { b.setBackground(new Color(0xFFA07A)); }
            public void mouseReleased(MouseEvent e) { b.setBackground(new Color(0xFFDAB9)); }
        });
        return b;
    }

    private String getGiftByPersonality(String p) {
        switch (p) {
            case "playful": return "squeaky toy";
            case "lazy": return "cozy blanket";
            case "grumpy": return "rare snack";
            default: return "treat";
        }
    }

    private void showDateOptions() {
        if (!pet.canGoOnDate()) {                               // refuse if not fully ready
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " is not ready for a date yet!",
                "Warning",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        if (pet.isSick()) {                                     // If the pet is sick, may refuse to date
            JOptionPane.showMessageDialog(
                this,
                pet.getName() + " is sick and cannot go on a date right now.",
                "Cannot Date",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        // List of potential dates
        List<Tamagotchi> candidates = Arrays.asList(               // create list of candidates
            new Tamagotchi("Pukatchi", "she/her"),                // candidate with name and pronouns
            new Tamagotchi("Gozarutchi", "he/him"),               
            new Tamagotchi("Violetchi", "she/her"),               
            new Tamagotchi("Onionitchi", "he/him")                
        );                                                       

        // Filter partners by matching pronouns
        List<String> partnerChoices = candidates.stream()         // start stream over candidates
            .filter(c -> {                                        // apply filter predicate
                String mine   = pet.getPronouns();               // get current pet’s pronouns
                String theirs = c.getPronouns();                 // get candidate’s pronouns
                if (mine.equals("he/him"))   return theirs.equals("she/her"); // he/him pets see she/her only
                if (mine.equals("she/her"))  return theirs.equals("he/him"); // she/her pets see he/him only
                return true;                                      // they/them pets see all
            })                                                    // end of filter
            .map(c -> c.getName() + " (" + c.getPronouns() + ")")// map to display string
            .collect(Collectors.toList());                       // collect to List<String>

        if (partnerChoices.isEmpty()) {                           // if no matches found
            JOptionPane.showMessageDialog(                        // show info dialog
                this,
                "No available dates right now.",
                "Dating",
                JOptionPane.INFORMATION_MESSAGE
            );                                                    // end showMessageDialog
            return;                                               // exit method
        }

        String[] pOpts = partnerChoices.toArray(new String[0]);   // convert List to array
        String partner = (String) JOptionPane.showInputDialog(    // show dropdown dialog
            this,
            "Who would you like to date?",
            "Select Date Partner",
            JOptionPane.QUESTION_MESSAGE,
            null,
            pOpts,                                                // options array
            pOpts[0]                                              // default selection
        );                                                        // end showInputDialog
        if (partner == null) return;                              // user cancelled

        // Now select date activity
        String[] activities = {"Watch Movie 🎬", "Coffee ☕", "Dinner 🍲", "Grab Drinks 🍹"}; // define date activities

        String activity = (String) JOptionPane.showInputDialog(   // show dropdown for activity
            this,
            "What activity for your date?",
            "Date Activity",
            JOptionPane.QUESTION_MESSAGE,
            null,
            activities,                                           // options array
            activities[0]                                         // default selection
        );                                                        // end showInputDialog
        if (activity == null) return;                             // user cancelled

        // Apply date logic
        logic.makeChoice("date", activity.split(" ")[0].toLowerCase()); // pass keyword to game logic

        // Confirm and boost happiness
        JOptionPane.showMessageDialog(                            // show success dialog
            this,
            "You went on a " + activity.split(" ")[0].toLowerCase() +
            " date with " + partner + "! 🎉",
            "Date Success",
            JOptionPane.INFORMATION_MESSAGE
        );                                                        // end showMessageDialog
        pet.changeHappiness(15);                                  // increase happiness

        updateStats();                                            // refresh progress bars
        checkPetStatus();                                         // check for game over
    }

    private void showFeedbackMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Action Result", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateStats() {                 // Refresh progress bars & status label
        healthBar.setValue(pet.getHealth());     // Set health bar
        happinessBar.setValue(pet.getHappiness()); // Set happiness bar
        hungerBar.setValue(pet.getHunger());     // Set hunger bar
        if (!pet.isAlive()) {                    // If pet dead, show game over
            statusLabel.setText(pet.getName() + " is dead! 😢");
            statusLabel.setForeground(Color.RED);
        } else if (pet.isSick()) {               // If sick, show warning
            statusLabel.setText(pet.getName() + " is sick! Take better care!");
            statusLabel.setForeground(Color.RED);
        } else if (pet.canGoOnDate()) {          // If eligible for date, show prompt
            statusLabel.setText(pet.getName() + " is ready for a date!️");
            statusLabel.setForeground(new Color(0xFF69B4));
        } else {                                 // Otherwise show happy state
            statusLabel.setText(pet.getName() + " is happy! (" + pet.getPersonality() + ")");
            statusLabel.setForeground(new Color(0x8B4513));
        }
    }

    private void checkDateEligibility() {     // Enable date when ready
        if (pet.canGoOnDate()) {
            //dateButton.setEnabled(true);
            showFeedbackMessage("Congratulations! " + pet.getName() + " is ready for a date!");
        }
    }
    
    private void updateAll() {
        updateStats();                                          // Refresh the three progress bars
        
        // Update status text and color based on pet's condition
        if (!pet.isAlive()) {                                    // If the pet has died
            statusLabel.setText(pet.getName() + " is dead! 😢");
            statusLabel.setForeground(Color.RED);                // Show text in red
        } else if (pet.isSick()) {                               // Else if the pet is sick
            statusLabel.setText(pet.getName() + " is sick! Take better care.");
            statusLabel.setForeground(Color.RED);                // Show warning in red
        } else if (pet.canGoOnDate()) {                          // Else if pet is ready to date
            statusLabel.setText(pet.getName() + " is ready for a date! ❤️");
            statusLabel.setForeground(new Color(0xFF69B4));      // Show in pink
        } else {                                                 // Default happy state
            statusLabel.setText(
                pet.getName() + " is happy! (" + pet.getPersonality() + ")"
            );
            statusLabel.setForeground(new Color(0x8B4513));      // Show in brown
        }
        
        // Enable date button only when eligible and not sick
        //dateButton.setEnabled(pet.canGoOnDate() && !pet.isSick());
    }

    private void checkPetStatus() {                                     // method to verify if pet is still alive
        if (!pet.isAlive()) {                                          // if pet’s health/happiness/hunger ≤ 0
            int choice = JOptionPane.showConfirmDialog(               // show a Yes/No dialog
                null,                                                 
                pet.getName() + " has died!\nGame over — play again?", // message with pet’s name
                "Game Over",                                          // dialog title
                JOptionPane.YES_NO_OPTION,                            // display Yes and No buttons
                JOptionPane.ERROR_MESSAGE                           
            );                                                        

            if (choice == JOptionPane.YES_OPTION) {                   // if user clicks “Yes”
                dispose();                                            // close current game window
                new StartScreen();                                    // launch the start screen
            } else {                                                  // if user clicks “No”
                System.exit(0);                                       // exit the application
            }                                                         // end else block
        }                                                             // end if pet.isAlive check
    }                                                                 // end checkPetStatus method

    private void updateCharacterDisplay(String character) { // Update character text
        characterLabel.setText(pet.getName() + " (" + character + ")");
    }

    private Icon createPlaceholderIcon(int w, int h) {     // Draw a icon
        return new Icon() {                       // Anonymous class for icon
            @Override public void paintIcon(Component c, Graphics g, int x, int y) {
                g.setColor(new Color(0xFFDAB9)); g.fillOval(x, y, w, h); // face
                g.setColor(new Color(0x8B4513)); g.drawOval(x, y, w, h); // outline
                g.fillOval(x + w/4, y + h/3, 10, 10); // left eye
                g.fillOval(x + 3*w/4 - 10, y + h/3, 10, 10); // right eye
                g.drawArc(x + w/4, y + 2*h/3, w/2, h/6, 0, -180); // mouth
            }
            @Override public int getIconWidth() { return w; }         // Icon width
            @Override public int getIconHeight() { return h; }        // Icon height
        };
    }
}
