/**
 * 
 */
/**
 * 
 */
module Tamagotchi {
	requires java.desktop;
}