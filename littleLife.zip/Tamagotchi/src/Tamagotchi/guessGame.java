package Tamagotchi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class guessGame extends JFrame implements ActionListener {
    private int numberToGuess;
    private int attempts;
    private int maxRange = 100;

    private JTextField guessBox;
    private JLabel instructionsLabel;
    private JButton guessButton;
    private JButton restartButton;
    private JComboBox<String> difficultyBox;
    private JButton exitButton;


    public guessGame() {

        // UI Components
        instructionsLabel = new JLabel("Guess a number between 1 and " + maxRange + ":");
        instructionsLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        instructionsLabel.setBounds(75, 30, 400, 30);

        guessBox = new JTextField(10);
        guessBox.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        guessBox.setBounds(100, 70, 200, 30);
        guessBox.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2, true));

        guessButton = new JButton("Guess");
        guessButton.setBounds(100, 110, 90, 30);
        guessButton.addActionListener(this);
        guessButton.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        guessButton.setForeground(new Color(0x8B4513));
        guessButton.setBackground(new Color(0xFFDAB9));
        guessButton.setFocusPainted(false);
        guessButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        guessButton.setPreferredSize(new Dimension(200, 60));
        guessButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2, true));
     
        

        restartButton = new JButton("Restart");
        restartButton.setBounds(210, 110, 90, 30);
        restartButton.addActionListener(this);
        restartButton.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        restartButton.setForeground(new Color(0x8B4513));
        restartButton.setBackground(new Color(0xFFDAB9));
        restartButton.setFocusPainted(false);
        restartButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        restartButton.setPreferredSize(new Dimension(200, 60));
        restartButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2, true));
        restartButton.addActionListener(e -> startNewGame());

        difficultyBox = new JComboBox<>(new String[]{"Easy", "Medium", "Hard"});
        difficultyBox.setBounds(125, 160, 150, 30);
        difficultyBox.addActionListener(e -> setDifficulty());
        
        exitButton = new JButton("Exit");
        exitButton.setBounds(150, 200, 90, 30);
        exitButton.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        exitButton.setForeground(new Color(0x8B4513));
        exitButton.setBackground(new Color(0xFFDAB9));
        exitButton.setFocusPainted(false);
        exitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2, true));
        exitButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                null,
                "Are you sure you want to exit?",
                "Exit Confirmation",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
            }
        });


      
        
        // Frame setup
        setTitle("Guessing Mini Game");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(252, 252, 206));
        setLayout(null);

        add(instructionsLabel);
        add(guessBox);
        add(guessButton);
        add(restartButton);
        add(difficultyBox);
        add(exitButton);

        startNewGame(); // Initialize the game
        setVisible(true);
    }

    private void setDifficulty() {
        String selected = (String) difficultyBox.getSelectedItem();
        if ("Easy".equals(selected)) {
            maxRange = 50;
        } else if ("Medium".equals(selected)) {
            maxRange = 100;
        } else {
            maxRange = 200;
        }
        startNewGame();
    }

    private void startNewGame() {
        numberToGuess = new Random().nextInt(maxRange) + 1;
        attempts = 0;
        instructionsLabel.setText("Guess a number between 1 and " + maxRange + ":");
        guessBox.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            int guess = Integer.parseInt(guessBox.getText().trim());
            attempts++;

            if (guess == numberToGuess) {
                JOptionPane.showMessageDialog(this, "Correct! You guessed it in " + attempts + " tries.");
                startNewGame();
            } else if (guess < numberToGuess) {
                JOptionPane.showMessageDialog(this, "Too low. Try again.");
            } else {
                JOptionPane.showMessageDialog(this, "Too high. Try again.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.");
        }
    }
    


  


    public static void main(String[] args) {
    	
        new guessGame();
        
    }
   
}
